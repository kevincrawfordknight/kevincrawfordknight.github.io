#!/usr/perl/bin

$trainedfile = shift;
if($trainedfile eq "") { print "arguments missing: extract-probs.pl trainedfile wfst1 [wfst2]\n"; exit; }

while($in = shift){ push @files, $in; }
if($#files < 0) { print "arguments missing: extract-probs.pl trainedfile wfst1 [wfst2]\n"; exit; }

print "\nreading trained composed file...\n";
open(TR, $trainedfile);
while($line = <TR>)
{
    if($line =~ /(.+)\s(.+?)!(.+?)\)\)/)
    {
	$prob{$3} = $2;
    }
}
close(TR);

foreach $file(@files)
{
    open(IN, $file);
    open(OUT, ">$file.trained");
    print "writing $file.trained...\n";
    $line = <IN>;
    print OUT $line;
    while($line = <IN>)
    {
	if($line =~ /(.+)\s(.+?)!(.+?)\)\)/)
	{
	    if($prob{$3})
	    {
		print OUT "$1 $prob{$3}!$3))\n";
	    }
	    #else
	    #{
	#	print OUT $line;
	#    }
	}
	#else
	#{
	#    print OUT $line;
	#}
    }
    close(IN);
    close(OUT);
}
