$B -rsim jpron.transducer vowel-separator.transducer         jpron-asciikana.transducer asciikana-katakana.transducer   < test.katakana
