cmd="$B -o 1.1 -M 4 -F span.spell.trained2 -t span.spell.corpus span.spell.wfst"
#$B -o 1.1 -M 3 -F span.spell.trained2 -t span.spell.corpus span.spell.wfst
echo $cmd
$cmd
echo $cmd
